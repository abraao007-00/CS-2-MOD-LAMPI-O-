# PowerShell · build.ps1 · CrimsonESP · Windows x64 · Visual Studio C++
param([ValidateSet('Release','Debug')][string]$Configuration='Release')
$ErrorActionPreference='Stop'
$vswhere='C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe'
$vs=& $vswhere -latest -prerelease -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if(!$vs){throw 'Instale o workload Desenvolvimento para desktop com C++ no Visual Studio.'}
$cmake=Join-Path $vs 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
if(!(Test-Path -LiteralPath $cmake)){$cmake=(Get-Command cmake -ErrorAction Stop).Source}
& $cmake -S $PSScriptRoot -B (Join-Path $PSScriptRoot 'build') -G 'Visual Studio 18 2026' -A x64
if($LASTEXITCODE){throw 'Falha ao configurar CMake'}
& $cmake --build (Join-Path $PSScriptRoot 'build') --config $Configuration --parallel
if($LASTEXITCODE){throw 'Falha ao compilar'}
$ctest=Join-Path (Split-Path $cmake) 'ctest.exe'
& $ctest --test-dir (Join-Path $PSScriptRoot 'build') -C $Configuration --output-on-failure
if($LASTEXITCODE){throw 'Falha na validacao'}
$dest=Join-Path $PSScriptRoot 'dist'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "build\$Configuration\CrimsonESP.exe") -Destination $dest -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "build\$Configuration\offset_probe.exe") -Destination $dest -Force
& (Join-Path $dest 'offset_probe.exe')
if($LASTEXITCODE){Write-Warning 'Aviso: CS2 nao encontrado no momento; offsets podem ser extraidos quando o jogo for aberto.'}
Write-Host "Pronto: $dest\CrimsonESP.exe"
