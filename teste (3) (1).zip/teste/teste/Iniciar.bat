@echo off
rem Batch - Iniciar.bat - lampião menu - Windows x64
cd /d "%~dp0"
if exist "dist\CrimsonESP_new.exe" (
  move /y "dist\CrimsonESP_new.exe" "dist\CrimsonESP.exe" >nul 2>&1
)
if not exist "dist\CrimsonESP.exe" (
  if exist "dist\CrimsonESP_new.exe" (
    copy /y "dist\CrimsonESP_new.exe" "dist\CrimsonESP.exe" >nul 2>&1
  ) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
    if errorlevel 1 (
      pause
      exit /b 1
    )
  )
)
start "" "%~dp0dist\CrimsonESP.exe"
