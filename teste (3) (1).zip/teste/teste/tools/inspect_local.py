import pathlib,struct,json
p=pathlib.Path(r'C:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive\game\csgo\bin\win64\client.dll')
b=p.read_bytes(); nt=struct.unpack_from('<I',b,60)[0]; opt=nt+24
base=struct.unpack_from('<Q',b,opt+24)[0]; size=struct.unpack_from('<I',b,opt+56)[0]
image=bytearray(size); image[:4096]=b[:4096]
sections=[]
for i in range(struct.unpack_from('<H',b,nt+6)[0]):
 s=opt+struct.unpack_from('<H',b,nt+20)[0]+i*40
 name=b[s:s+8].rstrip(b'\0').decode(); vs,va,rs,rp=struct.unpack_from('<IIII',b,s+8)
 image[va:va+rs]=b[rp:rp+rs];sections.append((name,va,vs))
def u64(o):return struct.unpack_from('<Q',image,o)[0]
def string(ptr):
 o=ptr-base
 if not 0<o<size:return ''
 end=image.find(0,o,o+200)
 return image[o:end].decode('ascii',errors='replace') if end>=0 else ''
classes=['C_BaseEntity','CGameSceneNode','CCSPlayerController','CBasePlayerController','CSkeletonInstance','CModelState','C_BaseModelEntity','C_BasePlayerPawn']
result={}
for name in classes:
 pos=0; found=[]
 while True:
  pos=image.find(name.encode()+b'\0',pos)
  if pos<0:break
  ptr=struct.pack('<Q',base+pos); q=0
  while True:
   q=image.find(ptr,q)
   if q<0:break
   d=q-8;q+=1
   if d<0 or d%8:continue
   sz,count=struct.unpack_from('<iH',image,d+32)
   f=u64(d+48)-base
   if not 0<sz<0x10000 or not 0<count<1500 or not 0<f<size-count*32:continue
   fields={};valid=True
   for j in range(count):
    n=string(u64(f+j*32));v=struct.unpack_from('<i',image,f+j*32+16)[0]
    if not n or not 0<=v<sz:valid=False;break
    fields[n]=hex(v)
   if valid:found.append({'rva':hex(d),'size':hex(sz),'fields':fields})
  pos+=1
 result[name]=found
print(json.dumps({'base':hex(base),'sections':sections,'classes':result},indent=2))
pathlib.Path('diagnostics/schema_inspect.json').write_text(json.dumps(result,indent=2))
