// C++20 · core.hpp · CS2 local practice · Windows x64 · MSVC
#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <winternl.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace crimson {
namespace fs = std::filesystem;
inline fs::path root() { wchar_t b[32768]{}; GetModuleFileNameW(nullptr,b,32768); return fs::path(b).parent_path(); }
inline std::string utf8(const std::wstring& s) {
    if(s.empty()) return {}; int n=WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0,nullptr,nullptr);
    std::string r(n,0); WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),r.data(),n,nullptr,nullptr); return r;
}
inline std::string escape(const std::string& s) {
    std::string r; for(unsigned char c:s) { if(c=='\\'||c=='"') r+='\\'; if(c>=32)r+=(char)c; } return r;
}
struct Vec3 { float x{},y{},z{}; };
inline float distance(Vec3 a,Vec3 b) { return std::sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)+(a.z-b.z)*(a.z-b.z)); }
inline bool sane(Vec3 v) { return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z)&&std::abs(v.x)<100000&&std::abs(v.y)<100000&&std::abs(v.z)<100000; }
struct Vec2 { float x{},y{}; };
using Matrix=std::array<float,16>;
inline bool project(Vec3 v,const Matrix& m,float w,float h,Vec2& out) {
    float z=m[12]*v.x+m[13]*v.y+m[14]*v.z+m[15];
    if(!sane(v)||!std::isfinite(z)||z<0.01f)return false;
    out={w*.5f*(1+(m[0]*v.x+m[1]*v.y+m[2]*v.z+m[3])/z),h*.5f*(1-(m[4]*v.x+m[5]*v.y+m[6]*v.z+m[7])/z)};
    return std::isfinite(out.x)&&std::isfinite(out.y)&&std::abs(out.x)<w*8&&std::abs(out.y)<h*8;
}
struct Handle {
    HANDLE value{}; Handle()=default; explicit Handle(HANDLE v):value(v){}
    ~Handle(){reset();} Handle(const Handle&)=delete; Handle& operator=(const Handle&)=delete;
    void reset(HANDLE v=nullptr){if(value&&value!=INVALID_HANDLE_VALUE)CloseHandle(value);value=v;}
    explicit operator bool()const{return value&&value!=INVALID_HANDLE_VALUE;}
};
class Image {
public:
    std::vector<uint8_t> data; uint64_t base{}; uint32_t timestamp{}; uint32_t textStart{},textSize{};
    explicit Image(const fs::path& path) {
        std::ifstream f(path,std::ios::binary); if(!f)throw std::runtime_error("Nao foi possivel abrir client.dll");
        std::vector<uint8_t> raw((std::istreambuf_iterator<char>(f)),{});
        auto get=[&]<class T>(size_t off){T v{};if(off>raw.size()||sizeof(T)>raw.size()-off)throw std::runtime_error("PE truncado");std::memcpy(&v,raw.data()+off,sizeof v);return v;};
        auto dos=get.operator()<IMAGE_DOS_HEADER>(0); if(dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<0)throw std::runtime_error("PE invalido");
        auto nt=get.operator()<IMAGE_NT_HEADERS64>(dos.e_lfanew);
        if(nt.Signature!=IMAGE_NT_SIGNATURE||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||nt.FileHeader.Machine!=IMAGE_FILE_MACHINE_AMD64)throw std::runtime_error("PE nao e x64");
        if(nt.OptionalHeader.SizeOfImage<4096||nt.OptionalHeader.SizeOfImage>512*1024*1024||nt.FileHeader.NumberOfSections>96)throw std::runtime_error("PE fora dos limites");
        base=nt.OptionalHeader.ImageBase;timestamp=nt.FileHeader.TimeDateStamp;data.resize(nt.OptionalHeader.SizeOfImage);
        std::memcpy(data.data(),raw.data(),std::min<size_t>({nt.OptionalHeader.SizeOfHeaders,raw.size(),data.size()}));
        size_t sh=dos.e_lfanew+24+nt.FileHeader.SizeOfOptionalHeader;
        for(size_t i=0;i<nt.FileHeader.NumberOfSections;++i){
            auto s=get.operator()<IMAGE_SECTION_HEADER>(sh+i*sizeof(IMAGE_SECTION_HEADER));
            if(s.VirtualAddress>data.size()||s.SizeOfRawData>data.size()-s.VirtualAddress||s.PointerToRawData>raw.size()||s.SizeOfRawData>raw.size()-s.PointerToRawData)throw std::runtime_error("Secao PE truncada");
            std::memcpy(data.data()+s.VirtualAddress,raw.data()+s.PointerToRawData,s.SizeOfRawData);
            if(std::memcmp(s.Name,".text",5)==0){textStart=s.VirtualAddress;textSize=s.SizeOfRawData;}
        }
    }
    template<class T>T at(size_t o)const{T v{};if(o<=data.size()&&sizeof(T)<=data.size()-o)std::memcpy(&v,data.data()+o,sizeof v);return v;}
    std::string string(uint64_t ptr)const {
        if(ptr<base||ptr-base>=data.size())return {};size_t p=(size_t)(ptr-base),e=p;
        while(e<data.size()&&e-p<200&&data[e])++e;
        if(e==data.size()||e-p>=200)return {};return std::string((char*)data.data()+p,e-p);
    }
    std::map<std::string,uint32_t> fields(const std::string& name)const {
        std::set<uint64_t> strings;
        auto start=data.begin();while(start!=data.end()){
            auto p=std::search(start,data.end(),name.begin(),name.end());if(p==data.end())break;
            auto n=(size_t)(p-data.begin()); if(n+name.size()<data.size()&&data[n+name.size()]==0)strings.insert(base+n);
            start=p+1;
        }
        std::map<std::string,uint32_t> result;bool found=false;
        for(size_t p=8;p+0x68<data.size();p+=8) {
            if(!strings.contains(at<uint64_t>(p)))continue;
            size_t d=p-8;int size=at<int>(d+0x20);auto count=at<uint16_t>(d+0x24);uint64_t ptr=at<uint64_t>(d+0x30);
            if(size<=0||size>0x100000||count==0||count>1500||ptr<base||ptr-base+count*32>data.size())continue;
            std::map<std::string,uint32_t> candidate;bool valid=true;
            for(unsigned i=0;i<count;++i){
                size_t field=(size_t)(ptr-base)+i*32;auto n=string(at<uint64_t>(field));auto off=at<int>(field+16);
                if(n.empty()||off<0||off>=size||!std::all_of(n.begin(),n.end(),[](unsigned char c){return std::isalnum(c)||c=='_';})||candidate.contains(n)){valid=false;break;}
                candidate[n]=(uint32_t)off;
            }
            if(valid){if(found&&result!=candidate)throw std::runtime_error("Schema ambiguo: "+name);result=std::move(candidate);found=true;}
        }
        if(!found)throw std::runtime_error("Classe ausente no schema local: "+name);return result;
    }
    uint32_t rip(const std::string& pattern)const {
        std::istringstream stream(pattern);std::string token;std::vector<int> bytes;
        while(stream>>token)bytes.push_back(token=="?"?-1:std::stoi(token,nullptr,16));
        std::set<uint32_t> matches;
        for(size_t p=textStart;p+bytes.size()<=size_t(textStart)+textSize;++p){
            bool ok=true;for(size_t j=0;j<bytes.size();++j)if(bytes[j]>=0&&data[p+j]!=bytes[j]){ok=false;break;}
            if(ok){auto dest=int64_t(p)+7+at<int32_t>(p+3);if(dest>0&&dest+64<(int64_t)data.size())matches.insert((uint32_t)dest);}
        }
        if(matches.size()!=1)throw std::runtime_error("Assinatura local ausente ou ambigua: "+pattern);return *matches.begin();
    }
};
struct Offsets {
    uint32_t entityList{},viewMatrix{},controller{},timestamp{};size_t imageSize{};
    std::map<std::string,uint32_t> schema;
    uint32_t get(const std::string& name)const{return schema.at(name);}
    static Offsets extract(const fs::path& path) {
        Image image(path);Offsets o;o.timestamp=image.timestamp;o.imageSize=image.data.size();
        o.entityList=image.rip("48 89 0D ? ? ? ? E9 ? ? ? ? CC");
        o.viewMatrix=image.rip("48 8D 0D ? ? ? ? 48 C1 E0 06");
        o.controller=image.rip("48 8B 05 ? ? ? ? 41 89 BE");
        const std::map<std::string,std::vector<std::string>> wanted={
            {"C_BaseEntity",{"m_iHealth","m_iTeamNum","m_lifeState","m_pGameSceneNode"}},
            {"CGameSceneNode",{"m_vecAbsOrigin","m_bDormant"}},
            {"CCSPlayerController",{"m_hPlayerPawn"}},
            {"CBasePlayerController",{"m_iszPlayerName"}},
            {"CSkeletonInstance",{"m_modelState"}},
            {"C_BaseModelEntity",{"m_vecViewOffset"}},
            {"C_CSPlayerPawn",{"m_ArmorValue"}}
        };
        for(const auto& [cls,names]:wanted){auto f=image.fields(cls);for(auto& n:names){if(!f.contains(n))throw std::runtime_error("Campo ausente: "+cls+"::"+n);o.schema[n]=f.at(n);}}
        return o;
    }
    void save(const fs::path& file,const fs::path& dll)const {
        std::ofstream f(file);f<<"{\n  \"source\": \""<<escape(utf8(dll.wstring()))<<"\",\n  \"timestamp\": "<<timestamp<<",\n  \"image_size\": "<<imageSize<<",\n  \"dwEntityList\": "<<entityList<<",\n  \"dwViewMatrix\": "<<viewMatrix<<",\n  \"dwLocalPlayerController\": "<<controller<<",\n  \"schema\": {";
        bool first=true;for(auto&[n,v]:schema){if(!first)f<<',';f<<"\n    \""<<n<<"\": "<<v;first=false;}f<<"\n  }\n}\n";
    }
};
inline fs::path installedDll(){
    std::vector<fs::path> libraries={L"C:\\Program Files (x86)\\Steam",L"D:\\SteamLibrary"};
    wchar_t steam[4096]{};DWORD bytes=sizeof steam;
    if(RegGetValueW(HKEY_CURRENT_USER,L"Software\\Valve\\Steam",L"SteamPath",RRF_RT_REG_SZ,nullptr,steam,&bytes)==ERROR_SUCCESS)libraries.emplace_back(steam);
    auto roots=libraries;
    for(const auto& r:roots){std::ifstream f(r/L"steamapps/libraryfolders.vdf");std::string line;while(std::getline(f,line)){
        if(line.find("\"path\"")==std::string::npos)continue;auto p=line.find('"',line.find("\"path\"")+6);auto e=line.find('"',p+1);
        if(p==std::string::npos||e==std::string::npos)continue;auto v=line.substr(p+1,e-p-1);std::string clean;
        for(size_t i=0;i<v.size();++i){clean+=v[i];if(v[i]=='\\'&&i+1<v.size()&&v[i+1]=='\\')++i;}libraries.push_back(fs::u8path(clean));
    }}
    for(const auto&r:libraries){auto p=r/L"steamapps/common/Counter-Strike Global Offensive/game/csgo/bin/win64/client.dll";if(fs::exists(p))return p;}
    return {};
}
class Process {
public:
    Handle handle;DWORD pid{};uint64_t base{};fs::path path;
    bool read(uint64_t p,void* b,size_t n)const {SIZE_T got{};return p>=0x10000&&p<0x7FFFFFFF0000&&handle&&ReadProcessMemory(handle.value,(void*)p,b,n,&got)&&got==n;}
    template<class T>bool read(uint64_t p,T&v)const{v={};return read(p,&v,sizeof v);}
    template<class T>T value(uint64_t p)const{T v{};read(p,v);return v;}
    bool alive()const{DWORD code{};return handle&&GetExitCodeProcess(handle.value,&code)&&code==STILL_ACTIVE;}
    void close(){handle.reset();pid=0;base=0;path.clear();}
    static DWORD find(){Handle h(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0));PROCESSENTRY32W e{sizeof e};if(Process32FirstW(h.value,&e))do{if(_wcsicmp(e.szExeFile,L"cs2.exe")==0)return e.th32ProcessID;}while(Process32NextW(h.value,&e));return 0;}
    std::wstring commandLine()const {
        using Query=NTSTATUS(NTAPI*)(HANDLE,PROCESSINFOCLASS,PVOID,ULONG,PULONG);
        auto q=(Query)GetProcAddress(GetModuleHandleW(L"ntdll.dll"),"NtQueryInformationProcess");if(!q)return {};
        ULONG size{};q(handle.value,(PROCESSINFOCLASS)60,nullptr,0,&size);if(size<sizeof(UNICODE_STRING)||size>1024*1024)return {};
        std::vector<uint8_t>b(size);if(q(handle.value,(PROCESSINFOCLASS)60,b.data(),size,&size)<0)return {};
        auto*s=(UNICODE_STRING*)b.data();auto p=(uintptr_t)s->Buffer,begin=(uintptr_t)b.data();
        if(p<begin||p+s->Length>begin+b.size()||s->Length%2)return {};return std::wstring(s->Buffer,s->Length/2);
    }
    bool open(DWORD id){
        close();handle.reset(OpenProcess(PROCESS_VM_READ|PROCESS_QUERY_INFORMATION,FALSE,id));if(!handle)return false;pid=id;
        Handle snap(CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid));MODULEENTRY32W m{sizeof m};
        if(Module32FirstW(snap.value,&m))do{if(_wcsicmp(m.szModule,L"client.dll")==0){base=(uint64_t)m.modBaseAddr;path=m.szExePath;return true;}}while(Module32NextW(snap.value,&m));
        close();return false;
    }
};
inline bool insecureToken(const std::wstring& command){std::wistringstream s(command);std::wstring t;while(s>>t){std::transform(t.begin(),t.end(),t.begin(),towlower);if(t==L"-insecure"||t==L"\"-insecure\"")return true;}return false;}
// [CONFIG] Exigência do parâmetro -insecure no CS2:
// false = desabilita a obrigatoriedade (permite rodar sem o parâmetro -insecure).
// true  = volta a exigir estritamente o parâmetro -insecure.
constexpr bool REQUIRE_INSECURE = false;
struct Player {Vec3 origin{},head{};std::array<Vec3,28>bones{};bool hasBones{},ally{};int health{},armor{};float meters{};std::string name;};
struct Snapshot {std::string status="Desconectado",detail="Aguardando cs2.exe...";bool connected{},ready{},insecure{};DWORD pid{};uint32_t timestamp{};int stride{},boneOffset=-1;float readMs{};Matrix matrix{};std::vector<Player> players;};
inline uint64_t entity(const Process&p,uint64_t list,uint32_t index,int stride){index&=0x7FFF;auto chunk=p.value<uint64_t>(list+0x10+8*(index>>9));return p.value<uint64_t>(chunk+(uint64_t)stride*(index&0x1FF));}
inline bool bones(const Process&p,uint64_t node,uint32_t model,Player& player,int& offset) {
    std::array<uint64_t,20> pointers{};if(!p.read(node+model,pointers))return false;
    auto candidate=[&](int i){
        struct Bone{Vec3 pos;float rest[5];};static_assert(sizeof(Bone)==32);std::array<Bone,28> b{};
        if(!p.read(pointers[i],b))return false;
        const int ids[]={0,2,4,5,6,8,9,10,13,14,15,22,23,24,25,26,27};
        for(int j:ids)if(!sane(b[j].pos)||distance(b[j].pos,player.origin)>150)return false;
        if(b[6].pos.z-player.origin.z<15||b[6].pos.z-player.origin.z>95||distance(b[6].pos,b[0].pos)<10)return false;
        for(auto pair:std::array<std::pair<int,int>,12>{{{6,5},{5,4},{4,2},{2,0},{4,8},{8,9},{9,10},{4,13},{13,14},{14,15},{22,23},{25,26}}}) {
            float d=distance(b[pair.first].pos,b[pair.second].pos);if(d<0.1f||d>55)return false;
        }
        for(size_t j=0;j<b.size();++j)player.bones[j]=b[j].pos;
        player.head=b[6].pos;player.hasBones=true;offset=i*8;return true;
    };
    if(offset>=0&&offset<160&&candidate(offset/8))return true;
    for(int i=0;i<(int)pointers.size();++i)if(i*8!=offset&&candidate(i))return true;return false;
}
class Reader {
    std::atomic<bool> quit{};std::thread worker;std::mutex mutex;Snapshot latest;
    void publish(Snapshot s){std::lock_guard lock(mutex);latest=std::move(s);}
    void run(){
        Process p;Offsets o;int stride=0,boneOffset=-1;bool processInsecure=false;auto next=std::chrono::steady_clock::now();
        while(!quit){auto now=std::chrono::steady_clock::now();
            if(!p.alive()){
                p.close();stride=0;boneOffset=-1;processInsecure=false;
                if(now<next){std::this_thread::sleep_for(std::chrono::milliseconds(40));continue;}
                next=now+std::chrono::seconds(2);Snapshot s;DWORD id=Process::find();
                if(!id){publish(s);continue;}
                s.pid=id;s.status="Conectando";s.detail="Verificando processo e DLL local";publish(s);
                if(!p.open(id)){s.status="Acesso indisponivel";s.detail="client.dll ainda nao carregou ou acesso negado";publish(s);continue;}
                processInsecure=insecureToken(p.commandLine());
                s.insecure=processInsecure;
                // Exigência de -insecure (desabilitada temporariamente; ative com REQUIRE_INSECURE = true)
                if constexpr (REQUIRE_INSECURE) {
                    if(!s.insecure){s.status="Aguardando -insecure";s.detail="Reabra o CS2 com o parametro de treinamento -insecure";publish(s);p.close();continue;}
                }
                try {
                    o=Offsets::extract(p.path);auto dos=p.value<IMAGE_DOS_HEADER>(p.base);auto nt=p.value<IMAGE_NT_HEADERS64>(p.base+dos.e_lfanew);
                    if(dos.e_magic!=IMAGE_DOS_SIGNATURE||nt.Signature!=IMAGE_NT_SIGNATURE||nt.FileHeader.TimeDateStamp!=o.timestamp||nt.OptionalHeader.SizeOfImage!=o.imageSize)throw std::runtime_error("DLL em memoria difere do arquivo instalado; reinicie o CS2");
                    o.save(root()/L"offsets_local.json",p.path);
                }catch(const std::exception&e){s.status="Offsets incompativeis";s.detail=e.what();publish(s);p.close();continue;}
            }
            Snapshot s;s.connected=true;s.insecure=processInsecure;s.pid=p.pid;s.timestamp=o.timestamp;s.status="Conectado";s.detail=processInsecure?"Entre em uma partida local de treinamento":"Conectado ao CS2";
            auto start=std::chrono::steady_clock::now();auto list=p.value<uint64_t>(p.base+o.entityList);auto local=p.value<uint64_t>(p.base+o.controller);
            if(!local||!list||!p.read(p.base+o.viewMatrix,s.matrix)){publish(s);std::this_thread::sleep_for(std::chrono::milliseconds(40));continue;}
            if(!stride){for(int size:{0x70,0x78,0x80})for(int i=1;i<=64;++i)if(entity(p,list,i,size)==local){stride=size;break;}}
            s.stride=stride;if(!stride){s.detail="Validando estrutura da lista de entidades";publish(s);std::this_thread::sleep_for(std::chrono::milliseconds(50));continue;}
            auto localPawn=entity(p,list,p.value<uint32_t>(local+o.get("m_hPlayerPawn")),stride);
            uint8_t team=p.value<uint8_t>(localPawn+o.get("m_iTeamNum"));auto localNode=p.value<uint64_t>(localPawn+o.get("m_pGameSceneNode"));Vec3 localPos=p.value<Vec3>(localNode+o.get("m_vecAbsOrigin"));
            if(team!=2&&team!=3){s.detail="Aguardando jogador local em equipe T ou CT";publish(s);std::this_thread::sleep_for(std::chrono::milliseconds(40));continue;}
            for(int i=1;i<=64;++i){
                auto c=entity(p,list,i,stride);if(!c||c==local)continue;uint32_t h{};if(!p.read(c+o.get("m_hPlayerPawn"),h)||h==0xFFFFFFFF)continue;
                auto pawn=entity(p,list,h,stride);if(!pawn||pawn==localPawn)continue;Player v;uint8_t t{},life{};
                if(!p.read(pawn+o.get("m_iHealth"),v.health)||!p.read(pawn+o.get("m_iTeamNum"),t)||!p.read(pawn+o.get("m_lifeState"),life)||v.health<=0||v.health>1000||life||(t!=2&&t!=3))continue;
                auto node=p.value<uint64_t>(pawn+o.get("m_pGameSceneNode"));bool dormant{};
                if(!node||!p.read(node+o.get("m_bDormant"),dormant)||dormant||!p.read(node+o.get("m_vecAbsOrigin"),v.origin)||!sane(v.origin))continue;
                Vec3 view=p.value<Vec3>(pawn+o.get("m_vecViewOffset"));v.head=v.origin;v.head.z+=(view.z>15&&view.z<90?view.z:64)+7;
                bones(p,node,o.get("m_modelState"),v,boneOffset);
                v.ally=t==team;v.meters=distance(localPos,v.origin)*.0254f;v.armor=std::clamp(p.value<int>(pawn+o.get("m_ArmorValue")),0,100);
                std::array<char,128> name{};p.read(c+o.get("m_iszPlayerName"),name);name.back()=0;v.name=name.data();if(v.name.empty())v.name="Jogador "+std::to_string(i);
                s.players.push_back(std::move(v));
            }
            s.ready=true;s.detail=processInsecure?"Treinamento -insecure | leitura externa":"Sessão ativa | leitura externa";s.boneOffset=boneOffset;s.readMs=std::chrono::duration<float,std::milli>(std::chrono::steady_clock::now()-start).count();
            publish(std::move(s));std::this_thread::sleep_for(std::chrono::milliseconds(8));
        }
    }
public:
    Reader(){worker=std::thread([this]{run();});}~Reader(){quit=true;if(worker.joinable())worker.join();}
    Snapshot snapshot(){std::lock_guard lock(mutex);return latest;}
};
struct Settings {
    bool enabled=false,enemies=true,allies=true,box=true,skeleton=true,names=true,health=true,armor=false,distance=true,head=true,snaplines=false,fill=false,outline=true,watermark=true;
    int boxType=1,lineOrigin=2,fps=144;float thickness=1.6f,skeletonWidth=1.5f,maxDistance=200,fillAlpha=.08f,fontSize=14,rounding=2,headRadius=4;
    float enemy[4]={1,.18f,.25f,1},ally[4]={.2f,.72f,1,1},bonesColor[4]={1,.82f,.83f,1};
    void normalize(){boxType=std::clamp(boxType,0,2);lineOrigin=std::clamp(lineOrigin,0,2);fps=std::clamp(fps,30,240);thickness=std::clamp(thickness,.5f,5.f);skeletonWidth=std::clamp(skeletonWidth,.5f,5.f);maxDistance=std::clamp(maxDistance,5.f,1000.f);fillAlpha=std::clamp(fillAlpha,0.f,.6f);fontSize=std::clamp(fontSize,10.f,24.f);rounding=std::clamp(rounding,0.f,15.f);headRadius=std::clamp(headRadius,1.f,15.f);for(auto a:{enemy,ally,bonesColor})for(int i=0;i<4;++i)a[i]=std::isfinite(a[i])?std::clamp(a[i],0.f,1.f):1.f;}
    void save(const fs::path& path)const {
        auto tmp=path;tmp+=L".tmp";std::ofstream f(tmp);if(!f)throw std::runtime_error("Nao foi possivel salvar o perfil");
#define SAVE(x) f<<#x<<'='<<x<<'\n'
        SAVE(enabled);SAVE(enemies);SAVE(allies);SAVE(box);SAVE(skeleton);SAVE(names);SAVE(health);SAVE(armor);SAVE(distance);SAVE(head);SAVE(snaplines);SAVE(fill);SAVE(outline);SAVE(watermark);SAVE(boxType);SAVE(lineOrigin);SAVE(fps);SAVE(thickness);SAVE(skeletonWidth);SAVE(maxDistance);SAVE(fillAlpha);SAVE(fontSize);SAVE(rounding);SAVE(headRadius);
#undef SAVE
        for(int i=0;i<4;++i)f<<"enemy"<<i<<'='<<enemy[i]<<'\n'<<"ally"<<i<<'='<<ally[i]<<'\n'<<"bones"<<i<<'='<<bonesColor[i]<<'\n';
        f.close();if(!f||!MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))throw std::runtime_error("Falha ao concluir o perfil");
    }
    bool load(const fs::path& path){std::ifstream f(path);if(!f)return false;Settings candidate=*this;std::string line;try{while(std::getline(f,line)){auto p=line.find('=');if(p==std::string::npos)continue;auto k=line.substr(0,p);float v=std::stof(line.substr(p+1));if(!std::isfinite(v))return false;
#define LOAD(x) if(k==#x){candidate.x=static_cast<decltype(x)>(v);continue;}
        LOAD(enabled);LOAD(enemies);LOAD(allies);LOAD(box);LOAD(skeleton);LOAD(names);LOAD(health);LOAD(armor);LOAD(distance);LOAD(head);LOAD(snaplines);LOAD(fill);LOAD(outline);LOAD(watermark);LOAD(boxType);LOAD(lineOrigin);LOAD(fps);LOAD(thickness);LOAD(skeletonWidth);LOAD(maxDistance);LOAD(fillAlpha);LOAD(fontSize);LOAD(rounding);LOAD(headRadius);
#undef LOAD
        for(int i=0;i<4;++i){auto n=std::to_string(i);if(k=="enemy"+n)candidate.enemy[i]=v;if(k=="ally"+n)candidate.ally[i]=v;if(k=="bones"+n)candidate.bonesColor[i]=v;}
        }}catch(...){return false;}candidate.normalize();*this=candidate;return true;}
};
}
