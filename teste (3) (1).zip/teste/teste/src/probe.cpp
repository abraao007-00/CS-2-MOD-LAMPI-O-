// C++20 · probe.cpp · local extraction and validation · Windows x64 · MSVC
#include "core.hpp"
#include <iostream>
int main(int argc,char**argv){
    using namespace crimson;
    try{
        if(argc>1&&std::string(argv[1])=="--watch"){
            int seconds=argc>2?std::clamp(std::atoi(argv[2]),1,600):30;Reader reader;
            for(int i=0;i<seconds;++i){auto s=reader.snapshot();int boneCount=0;for(auto&p:s.players)boneCount+=p.hasBones?1:0;
                std::cout<<"status="<<s.status<<" pid="<<s.pid<<" ready="<<s.ready<<" stride="<<s.stride<<" players="<<s.players.size()<<" skeletons="<<boneCount<<" boneOffset="<<s.boneOffset<<" readMs="<<s.readMs<<" detail="<<s.detail<<std::endl;
                if(s.ready){std::ofstream f(root()/L"runtime_diagnostics.json");f<<"{\"pid\":"<<s.pid<<",\"ready\":true,\"players\":"<<s.players.size()<<",\"skeletons\":"<<boneCount<<",\"stride\":"<<s.stride<<",\"bone_offset\":"<<s.boneOffset<<",\"read_ms\":"<<s.readMs<<",\"timestamp\":"<<s.timestamp<<"}\n";}
                std::this_thread::sleep_for(std::chrono::seconds(1));
            }return 0;
        }
        if(argc>1&&std::string(argv[1])=="--self-test"){
            int failures=0,checks=0;auto check=[&](bool ok,const char*n){++checks;std::cout<<(ok?"PASS ":"FAIL ")<<n<<'\n';if(!ok)++failures;};
            Matrix m{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};Vec2 p;
            check(project({0,0,0},m,1920,1080,p)&&p.x==960&&p.y==540,"projection center");
            check(project({1,1,0},m,1920,1080,p)&&p.x==1920&&p.y==0,"projection axes");
            m[15]=-1;check(!project({0,0,0},m,1920,1080,p),"behind camera rejected");
            check(insecureToken(L"cs2.exe -insecure -novid"),"insecure token");
            check(!insecureToken(L"cs2.exe -insecurex"),"partial token rejected");
            check(!insecureToken(L"cs2.exe"),"secure process rejected");
            check(!sane({NAN,0,0}),"invalid coordinate rejected");
            auto file=fs::temp_directory_path()/L"crimson_settings_test.ini";Settings a;a.thickness=3.25f;a.enemy[2]=.48f;a.save(file);Settings b;
            check(b.load(file)&&b.thickness==a.thickness&&b.enemy[2]==a.enemy[2],"profile roundtrip");
            {std::ofstream f(file);f<<"boxType=99\nfps=-2\nthickness=300\n";}check(b.load(file)&&b.boxType==2&&b.fps==30&&b.thickness==5,"profile limits");
            {std::ofstream f(file);f<<"enemy0=nan\n";}float old=b.enemy[0];check(!b.load(file)&&b.enemy[0]==old,"invalid profile atomic rejection");fs::remove(file);
            std::cout<<checks-failures<<'/'<<checks<<" passed\n";return failures?1:0;
        }
        auto path=argc>1?fs::u8path(argv[1]):installedDll();if(path.empty())throw std::runtime_error("CS2 instalado nao encontrado");
        auto o=Offsets::extract(path);o.save(root()/L"offsets_local.json",path);
        std::cout<<"DLL: "<<utf8(path.wstring())<<"\nTimestamp: 0x"<<std::hex<<o.timestamp<<"\nEntityList: 0x"<<o.entityList<<"\nViewMatrix: 0x"<<o.viewMatrix<<"\nController: 0x"<<o.controller<<'\n';
        for(auto&[n,v]:o.schema)std::cout<<n<<": 0x"<<v<<'\n';return 0;
    }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
}
