// C++20 · main.cpp · Crimson external ESP · Windows x64 · MSVC + DirectX 11
#include "core.hpp"
#include <d3d11.h>
#include <dwmapi.h>
#include <shellapi.h>
#include <wincodec.h>
#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>
#include <cstdio>

#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")

using namespace crimson;
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
static ID3D11Device* device{};static ID3D11DeviceContext* context{};
static ImFont* regular{};static ImFont* titleFont{};static ImFont* smallFont{};
static HWND mainWindow{},overlayWindow{};static bool running=true;
static constexpr ImVec4 red{.95f,.16f,.24f,1},muted{.51f,.52f,.58f,1},white{.93f,.93f,.96f,1};

struct BannerTexture {
    ID3D11ShaderResourceView* srv{};
    int width{}, height{};
    void release() {
        if (srv) { srv->Release(); srv = nullptr; }
        width = 0; height = 0;
    }
};
static BannerTexture banner;

static bool loadTextureFromFile(ID3D11Device* dev, const fs::path& path, BannerTexture& out) {
    std::error_code ec;
    if (!fs::exists(path, ec)) return false;
    IWICImagingFactory* factory{};
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory)))) return false;
    IWICBitmapDecoder* decoder{};
    if (FAILED(factory->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &decoder))) {
        factory->Release(); return false;
    }
    IWICBitmapFrameDecode* frame{};
    if (FAILED(decoder->GetFrame(0, &frame))) {
        decoder->Release(); factory->Release(); return false;
    }
    IWICFormatConverter* converter{};
    if (FAILED(factory->CreateFormatConverter(&converter))) {
        frame->Release(); decoder->Release(); factory->Release(); return false;
    }
    if (FAILED(converter->Initialize(frame, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom))) {
        converter->Release(); frame->Release(); decoder->Release(); factory->Release(); return false;
    }
    UINT w{}, h{};
    converter->GetSize(&w, &h);
    if (w == 0 || h == 0) {
        converter->Release(); frame->Release(); decoder->Release(); factory->Release(); return false;
    }
    std::vector<uint8_t> pixels(w * h * 4);
    if (FAILED(converter->CopyPixels(nullptr, w * 4, (UINT)pixels.size(), pixels.data()))) {
        converter->Release(); frame->Release(); decoder->Release(); factory->Release(); return false;
    }
    converter->Release(); frame->Release(); decoder->Release(); factory->Release();

    D3D11_TEXTURE2D_DESC desc{};
    desc.Width = w; desc.Height = h; desc.MipLevels = 1; desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    D3D11_SUBRESOURCE_DATA initData{};
    initData.pSysMem = pixels.data();
    initData.SysMemPitch = w * 4;

    ID3D11Texture2D* tex{};
    if (FAILED(dev->CreateTexture2D(&desc, &initData, &tex))) return false;

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc{};
    srvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;

    ID3D11ShaderResourceView* srv{};
    HRESULT hr = dev->CreateShaderResourceView(tex, &srvDesc, &srv);
    tex->Release();
    if (SUCCEEDED(hr) && srv) {
        out.release();
        out.srv = srv;
        out.width = (int)w;
        out.height = (int)h;
        return true;
    }
    return false;
}

static bool refreshBanner() {
    if (!device) return false;
    static const wchar_t* candidates[] = {
        L"banner.png", L"banner.jpg", L"banner.jpeg", L"banner.bmp",
        L"logo.png", L"logo.jpg", L"logo.bmp"
    };
    for (auto* name : candidates) {
        if (loadTextureFromFile(device, root() / name, banner)) return true;
        if (loadTextureFromFile(device, root().parent_path() / name, banner)) return true;
        if (loadTextureFromFile(device, fs::current_path() / name, banner)) return true;
    }
    return false;
}
struct Surface {
    HWND hwnd{};IDXGISwapChain* swap{};ID3D11RenderTargetView* target{};ImGuiContext* gui{};int width{},height{};
    bool init(HWND w,int x,int y){
        hwnd=w;width=x;height=y;IDXGIDevice* dx{};IDXGIAdapter* a{};IDXGIFactory* f{};
        if(FAILED(device->QueryInterface(IID_PPV_ARGS(&dx))))return false;
        HRESULT hr=dx->GetAdapter(&a);if(SUCCEEDED(hr))hr=a->GetParent(IID_PPV_ARGS(&f));
        DXGI_SWAP_CHAIN_DESC d{};d.BufferCount=2;d.BufferDesc.Width=x;d.BufferDesc.Height=y;d.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
        d.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;d.OutputWindow=w;d.SampleDesc.Count=1;d.Windowed=TRUE;d.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
        if(SUCCEEDED(hr))hr=f->CreateSwapChain(device,&d,&swap);if(f){f->MakeWindowAssociation(w,DXGI_MWA_NO_ALT_ENTER);f->Release();}if(a)a->Release();dx->Release();
        if(FAILED(hr)||!makeTarget())return false;
        gui=ImGui::CreateContext();ImGui::SetCurrentContext(gui);auto&io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;
        ImFontConfig cfg;cfg.OversampleH=2;cfg.OversampleV=2;cfg.PixelSnapH=true;
        auto*font=io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeui.ttf",17,&cfg,io.Fonts->GetGlyphRangesDefault());
        if(!font)font=io.Fonts->AddFontDefault();
        if(w==mainWindow){regular=font;titleFont=io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeuib.ttf",30,&cfg);smallFont=io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeui.ttf",14,&cfg);if(!titleFont)titleFont=regular;if(!smallFont)smallFont=regular;}
        ImGui_ImplWin32_Init(w);ImGui_ImplDX11_Init(device,context);return true;
    }
    bool makeTarget(){ID3D11Texture2D*b{};if(FAILED(swap->GetBuffer(0,IID_PPV_ARGS(&b))))return false;auto hr=device->CreateRenderTargetView(b,nullptr,&target);b->Release();return SUCCEEDED(hr);}
    bool resize(int w,int h){if(w<=0||h<=0)return false;if(w==width&&h==height)return true;context->OMSetRenderTargets(0,nullptr,nullptr);if(target){target->Release();target=nullptr;}width=w;height=h;return SUCCEEDED(swap->ResizeBuffers(0,w,h,DXGI_FORMAT_UNKNOWN,0))&&makeTarget();}
    void begin(){ImGui::SetCurrentContext(gui);ImGui_ImplDX11_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();}
    void render(bool panel){ImGui::Render();float clear[4]={panel?.035f:0,panel?.035f:0,panel?.045f:0,panel?1.f:0};context->OMSetRenderTargets(1,&target,nullptr);context->ClearRenderTargetView(target,clear);ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());}
    void destroy(){if(gui){ImGui::SetCurrentContext(gui);ImGui_ImplDX11_Shutdown();ImGui_ImplWin32_Shutdown();ImGui::DestroyContext(gui);gui=nullptr;}if(target)target->Release();if(swap)swap->Release();target=nullptr;swap=nullptr;}
};
static Surface panel,overlay;
static LRESULT CALLBACK wndproc(HWND h,UINT msg,WPARAM w,LPARAM l){
    auto* s=h==mainWindow?&panel:&overlay;if(s->gui){ImGui::SetCurrentContext(s->gui);if(ImGui_ImplWin32_WndProcHandler(h,msg,w,l))return 1;}
    if(msg==WM_CLOSE){if(h==mainWindow)running=false;return 0;}
    if(msg==WM_DESTROY){if(h==mainWindow)running=false;return 0;}
    if(msg==WM_GETMINMAXINFO&&h==mainWindow){auto*i=(MINMAXINFO*)l;i->ptMinTrackSize={1080,780};return 0;}
    if(msg==WM_NCHITTEST&&h==overlayWindow)return HTTRANSPARENT;
    if(msg==WM_ERASEBKGND)return 1;
    if(msg==WM_SYSCOMMAND&&(w&0xFFF0)==SC_KEYMENU)return 0;
    return DefWindowProcW(h,msg,w,l);
}
static void theme(){
    auto&s=ImGui::GetStyle();s.WindowPadding={0,0};s.FramePadding={12,8};s.ItemSpacing={12,12};s.ItemInnerSpacing={8,5};s.WindowRounding=0;s.ChildRounding=12;s.FrameRounding=6;s.PopupRounding=8;s.GrabRounding=4;s.ScrollbarRounding=8;s.ScrollbarSize=5;s.WindowBorderSize=0;s.ChildBorderSize=1;
    auto*c=s.Colors;c[ImGuiCol_Text]=white;c[ImGuiCol_TextDisabled]=muted;c[ImGuiCol_WindowBg]={.035f,.035f,.045f,1};c[ImGuiCol_ChildBg]={.057f,.057f,.073f,1};c[ImGuiCol_Border]={.14f,.13f,.17f,1};c[ImGuiCol_FrameBg]={.10f,.10f,.13f,1};c[ImGuiCol_FrameBgHovered]={.17f,.09f,.12f,1};c[ImGuiCol_FrameBgActive]={.24f,.08f,.12f,1};c[ImGuiCol_CheckMark]=red;c[ImGuiCol_SliderGrab]=red;c[ImGuiCol_SliderGrabActive]={1,.3f,.36f,1};c[ImGuiCol_Button]={.18f,.075f,.10f,1};c[ImGuiCol_ButtonHovered]={.31f,.09f,.13f,1};c[ImGuiCol_ButtonActive]=red;c[ImGuiCol_Header]={.25f,.075f,.11f,1};c[ImGuiCol_HeaderHovered]={.32f,.09f,.13f,1};c[ImGuiCol_HeaderActive]=red;c[ImGuiCol_Separator]=c[ImGuiCol_Border];c[ImGuiCol_PopupBg]={.07f,.07f,.09f,1};c[ImGuiCol_ScrollbarBg]={0,0,0,0};c[ImGuiCol_ScrollbarGrab]={.28f,.12f,.16f,1};
}
static ImU32 color(const float* c,float alpha=1){return ImGui::ColorConvertFloat4ToU32({c[0],c[1],c[2],c[3]*alpha});}
static void label(ImDrawList*d,ImVec2 at,const std::string& t,ImU32 c,float size,bool centered=true){
    auto*f=ImGui::GetFont();auto dim=f->CalcTextSizeA(size,FLT_MAX,0,t.c_str());if(centered)at.x-=dim.x*.5f;
    d->AddText(f,size,{at.x+1,at.y+1},IM_COL32(8,8,12,230),t.c_str());d->AddText(f,size,at,c,t.c_str());
}
static constexpr std::array<std::pair<int,int>,16> links={{{6,5},{5,4},{4,2},{2,0},{4,8},{8,9},{9,10},{4,13},{13,14},{14,15},{0,22},{22,23},{23,24},{0,25},{25,26},{26,27}}};
struct Actor {ImVec2 feet{},top{},head{};std::array<ImVec2,28>b{};std::array<bool,28>valid{};std::array<ImVec2,8>corners{};bool cube{};};
static void actor(ImDrawList*d,const Player&p,const Actor&a,const Settings&s,ImVec2 viewport,bool preview=false){
    if(!s.enabled&&!preview)return;if((p.ally&&!s.allies)||(!p.ally&&!s.enemies)||p.meters>s.maxDistance)return;
    float h=a.feet.y-a.top.y;if(h<8||h>viewport.y*3)return;float w=h*.44f;float left=a.top.x-w*.5f,right=a.top.x+w*.5f;
    ImU32 c=color(p.ally?s.ally:s.enemy),dark=IM_COL32(9,9,14,235);ImVec2 tl{left,a.top.y},br{right,a.feet.y};
    if(s.fill)d->AddRectFilled(tl,br,color(p.ally?s.ally:s.enemy,s.fillAlpha),s.rounding);
    auto line=[&](ImVec2 x,ImVec2 y,ImU32 col,float thickness){if(s.outline)d->AddLine(x,y,dark,thickness+2);d->AddLine(x,y,col,thickness);};
    if(s.box){
        if(s.boxType==2&&a.cube){static const int edge[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};for(auto&e:edge)line(a.corners[e[0]],a.corners[e[1]],c,s.thickness);}
        else if(s.boxType==1){float x=w*.26f,y=h*.17f;for(float xx:{left,right})for(float yy:{a.top.y,a.feet.y}){line({xx,yy},{xx+(xx==left?x:-x),yy},c,s.thickness);line({xx,yy},{xx,yy+(yy==a.top.y?y:-y)},c,s.thickness);}}
        else{if(s.outline)d->AddRect({left-1,a.top.y-1},{right+1,a.feet.y+1},dark,s.rounding,0,s.thickness+2);d->AddRect(tl,br,c,s.rounding,0,s.thickness);}
    }
    if(s.skeleton)for(auto [x,y]:links)if(a.valid[x]&&a.valid[y])line(a.b[x],a.b[y],color(s.bonesColor),s.skeletonWidth);
    if(s.head){if(s.outline)d->AddCircle(a.head,s.headRadius,dark,20,s.thickness+2);d->AddCircle(a.head,s.headRadius,c,20,s.thickness);}
    if(s.names)label(d,{a.top.x,a.top.y-s.fontSize-6},p.name,IM_COL32(236,236,245,255),s.fontSize);
    if(s.health){float fill=std::clamp(p.health/100.f,0.f,1.f);d->AddRectFilled({left-8,a.top.y-1},{left-3,a.feet.y+1},dark);d->AddRectFilled({left-7,a.feet.y-h*fill},{left-4,a.feet.y},IM_COL32((int)(255*(1-fill)),(int)(200*fill+35),82,255));if(p.health<100)label(d,{left-16,a.feet.y-h*fill-7},std::to_string(p.health),IM_COL32_WHITE,11);}
    if(s.armor){d->AddRectFilled({left,a.feet.y+4},{right,a.feet.y+7},dark);d->AddRectFilled({left,a.feet.y+4},{left+w*std::clamp(p.armor/100.f,0.f,1.f),a.feet.y+7},IM_COL32(90,155,235,255));}
    if(s.distance){char t[32];std::snprintf(t,sizeof t,"%.0f m",p.meters);label(d,{a.top.x,a.feet.y+(s.armor?12.f:6.f)},t,c,s.fontSize-1);}
    if(s.snaplines){float y=s.lineOrigin==0?0:s.lineOrigin==1?viewport.y*.5f:viewport.y;line({viewport.x*.5f,y},a.feet,c,.9f);}
}
static bool screenActor(const Player&p,const Snapshot&snap,float w,float h,Actor&a){
    Vec2 v;Vec3 top=p.head;top.z+=8;if(!project(p.origin,snap.matrix,w,h,v))return false;a.feet={v.x,v.y};if(!project(top,snap.matrix,w,h,v))return false;a.top={v.x,v.y};if(!project(p.head,snap.matrix,w,h,v))return false;a.head={v.x,v.y};
    if(p.hasBones)for(size_t i=0;i<28;++i){a.valid[i]=project(p.bones[i],snap.matrix,w,h,v);a.b[i]={v.x,v.y};}
    float z=top.z-p.origin.z;a.cube=true;for(int i=0;i<8;++i){Vec3 c=p.origin;c.x+=(i%4==0||i%4==3)?-16.f:16.f;c.y+=(i%4<2)?-16.f:16.f;c.z+=i<4?0:z;if(!project(c,snap.matrix,w,h,v))a.cube=false;a.corners[i]={v.x,v.y};}return true;
}
static bool gameRect(DWORD pid,RECT&result,HWND&game){
    struct Search{DWORD pid;HWND hwnd;};Search x{pid,nullptr};
    EnumWindows([](HWND h,LPARAM l)->BOOL{auto*x=(Search*)l;DWORD id{};GetWindowThreadProcessId(h,&id);if(id==x->pid&&IsWindowVisible(h)&&GetWindow(h,GW_OWNER)==nullptr){RECT r{};GetClientRect(h,&r);if(r.right>300&&r.bottom>200){x->hwnd=h;return FALSE;}}return TRUE;},(LPARAM)&x);
    game=x.hwnd;if(!game||IsIconic(game))return false;RECT r{};GetClientRect(game,&r);POINT p{0,0};ClientToScreen(game,&p);result={p.x,p.y,p.x+r.right,p.y+r.bottom};return true;
}
static bool toggle(const char*name,bool&value,const char*note=nullptr){
    ImGui::PushID(name);ImGui::BeginGroup();ImGui::TextUnformatted(name);if(note){ImGui::PushFont(smallFont);ImGui::TextColored(muted,"%s",note);ImGui::PopFont();}ImGui::EndGroup();
    float width=39,h=21;ImGui::SameLine(ImGui::GetWindowContentRegionMax().x-width);auto p=ImGui::GetCursorScreenPos();bool changed=ImGui::InvisibleButton("switch",{width,h});if(changed)value=!value;
    auto*d=ImGui::GetWindowDrawList();d->AddRectFilled(p,{p.x+width,p.y+h},value?IM_COL32(225,38,60,255):IM_COL32(49,49,61,255),h*.5f);d->AddCircleFilled({p.x+(value?width-h*.5f:h*.5f),p.y+h*.5f},7.5f,value?IM_COL32_WHITE:IM_COL32(150,151,167,255));ImGui::PopID();return changed;
}
static void heading(const char*name,const char*subtitle=nullptr){ImGui::PushFont(titleFont);ImGui::TextUnformatted(name);ImGui::PopFont();if(subtitle)ImGui::TextColored(muted,"%s",subtitle);ImGui::Spacing();}
static void cardStart(const char*id,float height=0){ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{20,18});ImGui::BeginChild(id,{0,height},ImGuiChildFlags_Borders|ImGuiChildFlags_AlwaysUseWindowPadding);}
static void cardEnd(){ImGui::EndChild();ImGui::PopStyleVar();}
static void section(const char*name){ImGui::TextColored({.91f,.54f,.58f,1},"%s",name);ImGui::Spacing();}
static void slider(const char*name,float&v,float low,float high,const char*format){ImGui::SetNextItemWidth(-1);ImGui::SliderFloat(name,&v,low,high,format);}
static void preview(const Settings&s,bool ally){
    auto pos=ImGui::GetCursorScreenPos();auto size=ImGui::GetContentRegionAvail();ImGui::InvisibleButton("preview_canvas",size);auto*d=ImGui::GetWindowDrawList();
    d->AddRectFilled(pos,{pos.x+size.x,pos.y+size.y},IM_COL32(13,13,19,255),8);
    for(float x=pos.x+20;x<pos.x+size.x;x+=28)d->AddLine({x,pos.y},{x,pos.y+size.y},IM_COL32(26,25,34,130));
    for(float y=pos.y+20;y<pos.y+size.y;y+=28)d->AddLine({pos.x,y},{pos.x+size.x,y},IM_COL32(26,25,34,130));
    float h=std::min(size.y-110,320.f),cx=pos.x+size.x*.5f,top=pos.y+55,bottom=top+h;
    d->AddEllipseFilled({cx,bottom+12},{h*.23f,11},IM_COL32(180,22,43,18));
    Actor a;a.top={cx,top};a.feet={cx,bottom};
    auto set=[&](int i,float x,float y){a.b[i]={cx+x*h,top+y*h};a.valid[i]=true;};
    set(6,0,.07f);set(5,0,.17f);set(4,0,.26f);set(2,0,.40f);set(0,0,.53f);set(8,-.11f,.23f);set(9,-.17f,.37f);set(10,-.16f,.51f);set(13,.11f,.23f);set(14,.18f,.37f);set(15,.17f,.51f);set(22,-.07f,.56f);set(23,-.09f,.77f);set(24,-.12f,.99f);set(25,.07f,.56f);set(26,.09f,.77f);set(27,.12f,.99f);a.head=a.b[6];
    d->AddCircleFilled(a.head,h*.05f,IM_COL32(91,78,91,200),24);
    for(auto[x,y]:links)d->AddLine(a.b[x],a.b[y],IM_COL32(56,48,62,200),x==6?h*.07f:h*.055f);
    a.cube=true;float ww=h*.22f,dd=18;for(int i=0;i<8;++i){bool upper=i>=4;int j=i%4;a.corners[i]={cx+((j==0||j==3)?-ww:ww)+(j>=2?dd:-dd),upper?top+(j>=2?-8.f:8.f):bottom+(j>=2?-8.f:8.f)};}
    Player p;p.name=ally?"ALIADO / CT":"INIMIGO / T";p.health=78;p.armor=65;p.meters=24;p.ally=ally;
    Settings copy=s;copy.snaplines=false;actor(d,p,a,copy,{pos.x+size.x,pos.y+size.y},true);
    label(d,{cx,pos.y+size.y-27},"PRÉVIA ILUSTRATIVA",IM_COL32(111,104,124,255),12);
}
static void ui(Settings&s,const Snapshot&snap,int&tab,std::string&toast){
    auto display=ImGui::GetIO().DisplaySize;ImGui::SetNextWindowPos({0,0});ImGui::SetNextWindowSize(display);
    ImGui::Begin("lampião menu",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);
    auto*d=ImGui::GetWindowDrawList();d->AddRectFilled({0,0},{196,display.y},IM_COL32(13,12,17,255));d->AddLine({196,0},{196,display.y},IM_COL32(46,26,35,255));
    d->AddRectFilledMultiColor({196,0},{display.x,130},IM_COL32(48,15,24,100),IM_COL32(14,14,19,0),IM_COL32(14,14,19,0),IM_COL32(14,14,19,0));
    float bannerH=0.f;
    if(banner.srv&&banner.width>0&&banner.height>0){
        float maxW=168.f,maxH=70.f;
        float scale=std::min(maxW/(float)banner.width,maxH/(float)banner.height);
        float bw=banner.width*scale,bh=banner.height*scale;
        float bx=14.f+(maxW-bw)*.5f;
        ImGui::SetCursorPos({bx,14.f});
        ImGui::Image((ImTextureID)banner.srv,{bw,bh});
        bannerH=bh+8.f;
    }else{
        d->AddRectFilled({14,14},{182,66},IM_COL32(24,16,22,230),8);
        d->AddRect({14,14},{182,66},IM_COL32(225,38,60,180),8,0,1.2f);
        label(d,{98,24},"LAMPIÃO",IM_COL32(250,250,255,255),15);
        label(d,{98,42},"BANNER (banner.png)",IM_COL32(240,70,90,255),10);
        bannerH=56.f;
    }
    float titleY=14.f+bannerH+4.f;
    ImGui::SetCursorPos({22,titleY});ImGui::PushFont(titleFont);ImGui::TextColored(red,"lampião");ImGui::SameLine();ImGui::TextUnformatted("menu");ImGui::PopFont();
    ImGui::SetCursorPos({25,titleY+32.f});ImGui::PushFont(smallFont);ImGui::TextColored(muted,"EXTERNAL / CS2");ImGui::PopFont();
    const char* tabs[]={"01   ESP","02   Aparência"};
    float tabsStartY=titleY+56.f;
    for(int i=0;i<2;++i){
        float ty=(i==0)?tabsStartY:(display.y-180.f);
        if(i==1){
            d->AddLine({20,ty-12.f},{176,ty-12.f},IM_COL32(50,30,42,160));
        }
        ImGui::SetCursorPos({14,ty});
        if(tab==i){
            d->AddRectFilled({0,ty+6.f},{3,ty+35.f},IM_COL32(242,40,62,255),2);
            ImGui::PushStyleColor(ImGuiCol_Button,{.23f,.07f,.105f,1});
            ImGui::PushStyleColor(ImGuiCol_Text,{1,.55f,.59f,1});
        }else{
            ImGui::PushStyleColor(ImGuiCol_Button,{0,0,0,0});
            ImGui::PushStyleColor(ImGuiCol_Text,muted);
        }
        if(ImGui::Button(tabs[i],{168,40}))tab=i;
        ImGui::PopStyleColor(2);
    }
    ImGui::SetCursorPos({24,display.y-121});ImGui::BeginGroup();ImGui::PushFont(smallFont);ImGui::TextColored(red,"TREINAMENTO LOCAL");ImGui::TextColored(muted,snap.insecure?"-insecure":"padrão");ImGui::Spacing();ImGui::TextColored(muted,"INSERT  painel");ImGui::TextColored(muted,"F6  ESP    END  sair");ImGui::PopFont();ImGui::EndGroup();
    float contentX=222,contentW=display.x-contentX-26;ImGui::SetCursorPos({contentX,25});
    ImGui::PushFont(smallFont);ImGui::TextColored(red,"VISÃO TÁTICA / PERSONALIZAÇÃO");ImGui::PopFont();
    ImGui::SetCursorPos({contentX,48});ImGui::PushFont(titleFont);ImGui::TextUnformatted("Seu campo. Sua visão.");ImGui::PopFont();
    ImGui::SetCursorPos({contentX,88});ImGui::TextColored(muted,"Controle visual completo para suas sessões de treinamento.");
    ImGui::SetCursorPos({display.x-247,30});ImGui::PushStyleColor(ImGuiCol_Button,s.enabled?ImVec4{.72f,.10f,.18f,1}:ImVec4{.13f,.11f,.15f,1});if(ImGui::Button(s.enabled?"ESP ATIVO   /   F6":"ATIVAR ESP   /   F6",{220,38})){s.enabled=!s.enabled;}ImGui::PopStyleColor();
    ImGui::SetCursorPos({display.x-247,79});ImGui::PushFont(smallFont);ImGui::TextColored(snap.connected?ImVec4{.36f,.86f,.61f,1}:muted,"%s",snap.status.c_str());ImGui::PopFont();
    float mainW=contentW*.59f,previewW=contentW-mainW-18;float bodyY=133,bodyH=display.y-bodyY-48;
    ImGui::SetCursorPos({contentX,bodyY});ImGui::BeginChild("controls",{mainW,bodyH});
    if(tab==0){
        cardStart("targets",179);section("ALVOS");toggle("Inimigos",s.enemies,"Destaque dos jogadores da equipe adversária");toggle("Aliados",s.allies,"Identificação da sua equipe");cardEnd();
        cardStart("elements",0);section("ELEMENTOS DO ESP");toggle("Box",s.box);toggle("Esqueleto",s.skeleton);toggle("Nome do jogador",s.names);toggle("Barra de vida",s.health);toggle("Barra de colete",s.armor);toggle("Distância",s.distance);toggle("Marcador de cabeça",s.head);toggle("Linhas de posição",s.snaplines);ImGui::Separator();slider("##range",s.maxDistance,5,500,"Alcance   %.0f m");cardEnd();
    }else{
        cardStart("appearance_combined",0);
        heading("Aparência & Configurações","Aparência, Cores, Perfis e Diagnóstico reunidos em uma só aba.");
        if(ImGui::BeginTabBar("settings_tab_bar",ImGuiTabBarFlags_FittingPolicyResizeDown)){
            if(ImGui::BeginTabItem("Aparência")){
                section("BANNER & IDENTIDADE");
                if(banner.srv&&banner.width>0) ImGui::TextColored({.36f,.86f,.61f,1},"Banner ativo: %dx%d px",banner.width,banner.height);
                else ImGui::TextColored(muted,"Nenhum banner encontrado (coloque banner.png na pasta)");
                if(ImGui::Button("Recarregar Banner",{170,30})){
                    if(refreshBanner()) toast="Banner recarregado com sucesso!";
                    else toast="banner.png nao encontrado na pasta";
                }
                ImGui::Separator();
                section("ESTILO DA BOX & OVERLAY");
                ImGui::TextColored(muted,"ESTILO DA BOX");ImGui::SetNextItemWidth(-1);ImGui::Combo("##box",&s.boxType,"Retângulo 2D\0Cantos\0Volume 3D\0");
                slider("##thickness",s.thickness,.5f,4,"Espessura da box   %.1f px");slider("##skeleton",s.skeletonWidth,.5f,4,"Espessura do esqueleto   %.1f px");slider("##round",s.rounding,0,12,"Arredondamento   %.0f px");slider("##font",s.fontSize,10,22,"Tamanho do texto   %.0f px");slider("##head",s.headRadius,1,12,"Raio da cabeça   %.0f px");
                toggle("Contorno de contraste",s.outline);toggle("Preenchimento da box",s.fill);if(s.fill)slider("##alpha",s.fillAlpha,0,.6f,"Opacidade do preenchimento   %.2f");
                ImGui::TextColored(muted,"ORIGEM DAS LINHAS");ImGui::SetNextItemWidth(-1);ImGui::Combo("##origin",&s.lineOrigin,"Topo\0Centro\0Base\0");toggle("Marca no overlay",s.watermark);
                ImGui::EndTabItem();
            }
            if(ImGui::BeginTabItem("Cores")){
                section("PALETA DE COMBATE");
                ImGui::TextColored(muted,"INIMIGOS");ImGui::ColorEdit4("##enemy",s.enemy,ImGuiColorEditFlags_AlphaBar|ImGuiColorEditFlags_DisplayRGB);ImGui::Spacing();
                ImGui::TextColored(muted,"ALIADOS");ImGui::ColorEdit4("##ally",s.ally,ImGuiColorEditFlags_AlphaBar|ImGuiColorEditFlags_DisplayRGB);ImGui::Spacing();
                ImGui::TextColored(muted,"ESQUELETO");ImGui::ColorEdit4("##bones",s.bonesColor,ImGuiColorEditFlags_AlphaBar|ImGuiColorEditFlags_DisplayRGB);ImGui::Spacing();
                ImGui::TextWrapped("As cores de equipe são aplicadas às boxes, cabeça, distância e linhas. O esqueleto tem uma cor própria.");ImGui::Spacing();
                if(ImGui::Button("Restaurar paleta padrão",{-1,36})){Settings defaults;std::copy_n(defaults.enemy,4,s.enemy);std::copy_n(defaults.ally,4,s.ally);std::copy_n(defaults.bonesColor,4,s.bonesColor);}
                ImGui::EndTabItem();
            }
            if(ImGui::BeginTabItem("Perfis")){
                section("PERFIS DE CONFIGURAÇÃO");
                for(int i=1;i<=3;++i){ImGui::PushID(i);ImGui::Text("PERFIL 0%d",i);auto path=root()/(L"perfil_"+std::to_wstring(i)+L".ini");if(ImGui::Button("Salvar",{130,36})){try{s.save(path);toast="Perfil "+std::to_string(i)+" salvo";}catch(const std::exception&e){toast=e.what();}}ImGui::SameLine();if(ImGui::Button("Carregar",{130,36}))toast=s.load(path)?"Perfil carregado":"Perfil ausente ou inválido";ImGui::Separator();ImGui::PopID();}
                ImGui::Spacing();section("PREDEFINIÇÕES");
                if(ImGui::Button("Essencial",{-1,35})){bool on=s.enabled;s=Settings{};s.enabled=on;s.skeleton=false;s.head=false;s.distance=false;s.allies=false;toast="Predefinição Essencial aplicada";}
                if(ImGui::Button("Completo",{-1,35})){bool on=s.enabled;s=Settings{};s.enabled=on;s.armor=true;s.fill=true;s.snaplines=true;toast="Predefinição Completo aplicada";}
                if(ImGui::Button("Restaurar padrão",{-1,35})){s=Settings{};toast="Padrão restaurado";}
                ImGui::EndTabItem();
            }
            if(ImGui::BeginTabItem("Diagnóstico")){
                section("CONEXÃO E LEITURA");
                ImGui::TextColored(red,"%s",snap.status.c_str());ImGui::TextWrapped("%s",snap.detail.c_str());ImGui::Separator();
                ImGui::Text("Processo: %lu",snap.pid);ImGui::Text("Parâmetro -insecure: %s",snap.insecure?"verificado":(REQUIRE_INSECURE?"aguardando":"desabilitado / opcional"));ImGui::Text("PE timestamp: %08X",snap.timestamp);ImGui::Text("Entidades válidas: %zu",snap.players.size());ImGui::Text("Leitura: %.2f ms",snap.readMs);ImGui::Text("Passo de entidade: 0x%X",snap.stride);
                if(snap.boneOffset>=0)ImGui::Text("Bones / model state: +0x%X",snap.boneOffset);else ImGui::TextColored(muted,"Bones: aguardando validação em partida");
                ImGui::Separator();ImGui::TextWrapped("Os offsets são extraídos do client.dll desta instalação. O arquivo offsets_local.json registra os valores e a identidade da DLL.");ImGui::Spacing();
                ImGui::SetNextItemWidth(-1);ImGui::SliderInt("##fps",&s.fps,30,240,"Limite do overlay: %d FPS");ImGui::Spacing();
                ImGui::TextWrapped("Use o CS2 em janela sem bordas. INSERT mostra ou oculta este painel; F6 liga ou pausa o ESP; END encerra o aplicativo.");
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }
        cardEnd();
    }
    ImGui::EndChild();
    ImGui::SetCursorPos({contentX+mainW+18,bodyY});ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{18,18});ImGui::BeginChild("livepreview",{previewW,bodyH},ImGuiChildFlags_Borders|ImGuiChildFlags_AlwaysUseWindowPadding);
    ImGui::TextUnformatted("PRÉVIA DO ESP");ImGui::SameLine();ImGui::PushFont(smallFont);ImGui::TextColored(red,"  AO VIVO");ImGui::PopFont();
    static int previewTeam=0;ImGui::SetNextItemWidth(-1);ImGui::Combo("##previewteam",&previewTeam,"Inimigo\0Aliado\0");
    ImGui::PushFont(smallFont);ImGui::TextColored(muted,"As alterações aparecem aqui na hora.");ImGui::PopFont();preview(s,previewTeam==1);ImGui::EndChild();ImGui::PopStyleVar();
    ImGui::SetCursorPos({contentX,display.y-32});ImGui::PushFont(smallFont);if(!toast.empty())ImGui::TextColored({.85f,.66f,.68f,1},"%s",toast.c_str());else ImGui::TextColored(muted,"LAMPIÃO MENU 1.0     /     DX11     /     %s",snap.connected?"CONECTADO":"DESCONECTADO");ImGui::PopFont();ImGui::End();
}
static bool capture(Surface&s,const fs::path&path){
    ID3D11Texture2D*source{};if(FAILED(s.swap->GetBuffer(0,IID_PPV_ARGS(&source))))return false;D3D11_TEXTURE2D_DESC desc{};source->GetDesc(&desc);desc.Usage=D3D11_USAGE_STAGING;desc.BindFlags=0;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;desc.MiscFlags=0;
    ID3D11Texture2D*staging{};auto hr=device->CreateTexture2D(&desc,nullptr,&staging);if(FAILED(hr)){source->Release();return false;}context->CopyResource(staging,source);D3D11_MAPPED_SUBRESOURCE m{};hr=context->Map(staging,0,D3D11_MAP_READ,0,&m);
    if(SUCCEEDED(hr)){BITMAPFILEHEADER file{};BITMAPINFOHEADER info{};file.bfType=0x4D42;file.bfOffBits=sizeof file+sizeof info;file.bfSize=file.bfOffBits+desc.Width*desc.Height*4;info.biSize=sizeof info;info.biWidth=desc.Width;info.biHeight=-(LONG)desc.Height;info.biPlanes=1;info.biBitCount=32;info.biCompression=BI_RGB;
        std::ofstream f(path,std::ios::binary);f.write((char*)&file,sizeof file);f.write((char*)&info,sizeof info);std::vector<uint8_t>row(desc.Width*4);
        for(UINT y=0;y<desc.Height;++y){auto*p=(uint8_t*)m.pData+y*m.RowPitch;for(UINT x=0;x<desc.Width;++x){row[x*4]=p[x*4+2];row[x*4+1]=p[x*4+1];row[x*4+2]=p[x*4];row[x*4+3]=255;}f.write((char*)row.data(),row.size());}context->Unmap(staging,0);hr=f?S_OK:E_FAIL;
    }staging->Release();source->Release();return SUCCEEDED(hr);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR command,int){
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    Handle single(CreateMutexW(nullptr,FALSE,L"Local\\LampiaoMenu.Panel.v1"));if(GetLastError()==ERROR_ALREADY_EXISTS){if(auto w=FindWindowW(L"LampiaoMain",nullptr)){ShowWindow(w,SW_RESTORE);SetForegroundWindow(w);}CoUninitialize();return 0;}
    const bool captureMode=std::wstring(command).find(L"--capture")!=std::wstring::npos;
    WNDCLASSEXW wc{sizeof wc};wc.lpfnWndProc=wndproc;wc.hInstance=instance;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.lpszClassName=L"LampiaoMain";RegisterClassExW(&wc);wc.lpszClassName=L"LampiaoOverlay";RegisterClassExW(&wc);
    RECT rect{0,0,1180,790};AdjustWindowRect(&rect,WS_OVERLAPPEDWINDOW,FALSE);
    mainWindow=CreateWindowExW(0,L"LampiaoMain",L"lampião menu",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,rect.right-rect.left,rect.bottom-rect.top,nullptr,nullptr,instance,nullptr);
    overlayWindow=CreateWindowExW(WS_EX_TOPMOST|WS_EX_TRANSPARENT|WS_EX_LAYERED|WS_EX_NOACTIVATE|WS_EX_TOOLWINDOW,L"LampiaoOverlay",L"lampião menu Overlay",WS_POPUP,0,0,1280,720,nullptr,nullptr,instance,nullptr);
    if(!mainWindow||!overlayWindow){MessageBoxW(nullptr,L"Falha ao criar janela",L"lampião menu",MB_ICONERROR);CoUninitialize();return 1;}
    SetLayeredWindowAttributes(overlayWindow,RGB(0,0,0),255,LWA_COLORKEY);MARGINS margins{-1,-1,-1,-1};DwmExtendFrameIntoClientArea(overlayWindow,&margins);BOOL dark=TRUE;DwmSetWindowAttribute(mainWindow,20,&dark,sizeof dark);
    D3D_FEATURE_LEVEL feature{};HRESULT hr=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,&feature,&context);
    if(FAILED(hr))hr=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,&feature,&context);
    if(FAILED(hr)||!panel.init(mainWindow,1180,790)||!overlay.init(overlayWindow,1280,720)){MessageBoxW(mainWindow,L"Falha ao iniciar DirectX 11",L"lampião menu",MB_ICONERROR);panel.destroy();overlay.destroy();if(context)context->Release();if(device)device->Release();CoUninitialize();return 2;}
    refreshBanner();
    ImGui::SetCurrentContext(panel.gui);theme();Settings settings;settings.load(root()/L"config.ini");settings.enabled=false;
    Reader reader;bool visible=true;int tab=0,frames=0;std::string toast;auto lastSave=std::chrono::steady_clock::now();
    RegisterHotKey(mainWindow,1,MOD_NOREPEAT,VK_INSERT);RegisterHotKey(mainWindow,2,MOD_NOREPEAT,VK_F6);RegisterHotKey(mainWindow,3,MOD_NOREPEAT,VK_END);
    ShowWindow(mainWindow,SW_SHOWDEFAULT);UpdateWindow(mainWindow);
    while(running){auto start=std::chrono::steady_clock::now();MSG msg{};
        while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT)running=false;if(msg.message==WM_HOTKEY){if(msg.wParam==1){visible=!visible;ShowWindow(mainWindow,visible?SW_SHOW:SW_HIDE);if(visible)SetForegroundWindow(mainWindow);}if(msg.wParam==2)settings.enabled=!settings.enabled;if(msg.wParam==3)running=false;}TranslateMessage(&msg);DispatchMessageW(&msg);}if(!running)break;
        Snapshot snap=reader.snapshot();
        if(visible&&!IsIconic(mainWindow)){RECT r{};GetClientRect(mainWindow,&r);if(!panel.resize(r.right,r.bottom)){running=false;break;}panel.begin();ui(settings,snap,tab,toast);panel.render(true);
            if(captureMode&&++frames==10){fs::path out=root()/L"preview.bmp";capture(panel,out);running=false;}
            if(FAILED(panel.swap->Present(0,0))){running=false;break;}
        }
        RECT game{};HWND gameWindow{};HWND fg=GetForegroundWindow();bool show=snap.ready&&settings.enabled&&gameRect(snap.pid,game,gameWindow)&&(fg==gameWindow||fg==mainWindow);
        if(show){int w=game.right-game.left,h=game.bottom-game.top;SetWindowPos(overlayWindow,HWND_TOPMOST,game.left,game.top,w,h,SWP_NOACTIVATE|SWP_SHOWWINDOW);
            if(visible&&fg==mainWindow)SetWindowPos(mainWindow,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
            if(!overlay.resize(w,h)){running=false;break;}overlay.begin();auto*d=ImGui::GetBackgroundDrawList();for(const auto&p:snap.players){Actor a;if(screenActor(p,snap,(float)w,(float)h,a))actor(d,p,a,settings,{(float)w,(float)h});}
            if(settings.watermark){d->AddRectFilled({14,14},{310,44},IM_COL32(16,12,19,220),5);d->AddRectFilled({14,14},{17,44},IM_COL32(240,40,60,255),2);label(d,{27,20},snap.insecure?"LAMPIÃO MENU / TREINAMENTO -insecure":"LAMPIÃO MENU / EXTERNAL",IM_COL32(245,136,148,255),13,false);}overlay.render(false);if(FAILED(overlay.swap->Present(0,0))){running=false;break;}
        }else ShowWindow(overlayWindow,SW_HIDE);
        if(fg!=mainWindow)SetWindowPos(mainWindow,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
        if(start-lastSave>std::chrono::seconds(3)){try{settings.save(root()/L"config.ini");}catch(const std::exception&e){toast=e.what();}lastSave=start;}
        auto budget=std::chrono::duration<double>(1.0/settings.fps);auto elapsed=std::chrono::steady_clock::now()-start;if(elapsed<budget)std::this_thread::sleep_for(budget-elapsed);
    }
    try{settings.save(root()/L"config.ini");}catch(...){}
    for(int i=1;i<=3;++i)UnregisterHotKey(mainWindow,i);banner.release();overlay.destroy();panel.destroy();context->Release();device->Release();DestroyWindow(overlayWindow);DestroyWindow(mainWindow);CoUninitialize();return 0;
}
